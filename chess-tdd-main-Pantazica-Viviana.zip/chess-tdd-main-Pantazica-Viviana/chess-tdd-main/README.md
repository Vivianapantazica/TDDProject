# chess-tdd

###### 1. Fork this repository into your personal GitHub account

###### 2. Implement the methods from the _Pawn_ and _Chessboard_ classes in order to make all unit tests pass

###### 3. Push the changes to your personal repository

###### 4. Raise a pull request against this repository