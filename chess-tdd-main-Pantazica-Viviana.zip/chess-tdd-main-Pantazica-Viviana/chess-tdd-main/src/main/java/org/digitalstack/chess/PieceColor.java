package org.digitalstack.chess;

public enum PieceColor {
    BLACK, WHITE;
}
