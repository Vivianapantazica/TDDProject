package org.digitalstack.chess;

public enum MovementType {
    MOVE, CAPTURE;
}
